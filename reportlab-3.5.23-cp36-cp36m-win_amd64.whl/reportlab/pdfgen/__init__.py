#Copyright ReportLab Europe Ltd. 2000-2017
#see license.txt for license details
#history https://bitbucket.org/rptlab/reportlab/history-node/tip/src/reportlab/pdfgen/__init__.py
__version__='3.3.0'
__doc__='''Defines a high-level Canvas interface for creating PDF files'''
