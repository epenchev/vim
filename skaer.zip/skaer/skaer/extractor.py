import queue
import cherrypy
import youtube_dl
from cherrypy.process.plugins import BackgroundTask

from .playlists import Library


class Service(object):
    """
    Extractor service to be run in the background.

    """
    # A simple singleton implementation.
    __instance = None

    def __new__(cls):
        if Service.__instance is None:
            Service.__instance = object.__new__(cls)
        return Service.__instance

    def __init__(self, interval_sec=1, queue_size=10, handler):
        """
        Construct a Service object.
        :param interval_sec: Time interval in secodns for task to be execued. 
        :param queue_size: Maximum queue size. If size is reached queue will start rejecting items.
        :param handler: Callable object to process queue items.

        """
        self._interval = interval_sec
        self._queue = queue.Queue(maxsize=queue_size)
        assert handler != None
        assert callable(handler) == True
        self._handler = handler

    def start(self):
        self._task = BackgroundTask(self._interval, self.handle_tasks)
        self._task.start()

    @property
    def queue(self):
        return self._queue

    def handle_tasks(self):
        try:
            item = self._queue.get(block=False)
            self._handler(item)
        except queue.Empty:
            return


class Extractor(object):
    """
    Extract playlist metadata from external sources and add the information to database.

    """
    def __init__(self):
        pass

    def __call__(self, url : str):
        # Extract data, long running blocking task
        with youtube_dl.YoutubeDL({'quiet': True, 'ignoreerrors': True}) as ydl:
            try:
                list_data = ydl.extract_info(url, download=False)
            except Exception:
                return None
            #list_data[]

    @staticmethod
    def audio_stream(self, vid : str) -> tuple:
          """
          Extract the url and mime type for the audio stream with youtube_dl.
          :param vid: video id or video url.

          """
          try:
               with youtube_dl.YoutubeDL({'quiet': True}) as ydl:
                    json_out = ydl.extract_info(vid, download=False)
          except (youtube_dl.utils.ExtractorError, youtube_dl.utils.DownloadError) as err:
               raise RuntimeError(str(err))

          streams = [f for f in json_out['formats'] if 'audio only' in f['format']]
          best_audio = sorted(streams, key=lambda audio: audio['abr'])[0]
          stream_url =  best_audio['url']
          ext = best_audio['ext']
          mime_type = 'audio/{}'.format(ext)
          return (stream_url, mime_type)
