import os
import json
import unittest
import requests
import threading
import cherrypy
import time


if 'DATABASE_URL' not in os.environ:
    os.environ['DATABASE_URL'] = r'postgresql://skaer:pass@localhost/skaerdb'

from skaer.app import Skaer
from skaer.tests.helpers import create_sample_playlist, drop_db_tables, verify_playlist_in_db, get_playlist_tracks_from_db

class CherrypyApp(threading.Thread):
    def __init__(self):
        super().__init__()

    def run(self):
        cherrypy.config.update({'environment': 'test_suite'}) # use 'staging' when debuging
        cherrypy.quickstart(Skaer(), '/api')

    def shutdown(self):  
        cherrypy.engine.exit()


class TestApp(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.app = CherrypyApp()
        cls.app.start()
        # Wait for the server to start
        time.sleep(2)
        cls.db_url = os.environ['DATABASE_URL']
        cls.playlists_api_url = r'http://127.0.0.1:8080/api/playlists'
        cls.playlist_items_api_url = r'http://127.0.0.1:8080/api/playlist_items'
        cls.session_id = '1'

    def test_app_playlist_list(self):
        """
        Test fetching available playlists.

        """
        api_url = r'http://127.0.0.1:8080/api/get_playlist'
        title = 'playlist_list_all'
        thumbnail = 'thumb.example'
        description = 'desc'
        create_sample_playlist(title, thumbnail, description, TestApp.db_url)
        # Get all playlists
        r = requests.get(api_url, params={'session_id': TestApp.session_id})
        r.raise_for_status()    
        self.assertTrue(r.headers.get('content-type', '').startswith('application/json'))
        json_obj = json.loads(r.json())
        all_playlists = json_obj['playlists']
        self.assertTrue(len(all_playlists) > 0)
        found = False
        list_id = None
        for playlist in all_playlists:
            if playlist['title'] == title and playlist['thumbnail'] == thumbnail:
                found = True
                list_id = playlist['id']
        self.assertTrue(found)
        r = requests.get(TestApp.playlists_api_url, params={'session_id': TestApp.session_id, 'list_id': list_id})
        self.assertTrue(r.headers.get('content-type', '').startswith('application/json'))
        json_obj = json.loads(r.json())
        self.assertEqual(json_obj['id'], list_id)
        self.assertEqual(json_obj['title'], title)

    def test_app_playlist_create(self):
        title = 'Testing app create'
        thumbnail = 'some thumbnail'
        r = requests.post(TestApp.playlists_api_url, params={'ssid': TestApp.session_id}, data=json.dumps({'title': title, 'thumbnail': thumbnail}))
        r.raise_for_status()
        self.assertTrue(r.headers.get('content-type', '').startswith('application/json'))
        json_obj = json.loads(r.json())
        self.assertTrue(json_obj['id'])
        self.assertEqual(json_obj['title'], title)
        self.assertEqual(json_obj['thumbnail'], thumbnail)
        # Verify list is in db
        self.assertTrue(verify_playlist_in_db(title, TestApp.db_url))
        # Test create samme playlist again, must return 409
        r = requests.post(TestApp.playlists_api_url, params={'ssid': TestApp.session_id}, data=json.dumps({'title': title, 'thumbnail': thumbnail + TestApp.session_id}))
        self.assertEqual(r.status_code, 409)

    def test_app_playlist_edit(self):
        title = 'Testing app edit'
        thumbnail = 'some thumbnail edit'
        # Create the playlist first
        list_id = create_sample_playlist(title, thumbnail, TestApp.db_url)
        title = 'Testing app edit new title'
        r = requests.put(TestApp.playlists_api_url, params={'ssid': TestApp.session_id, 'lid': list_id}, data=json.dumps({'title': title, 'thumbnail': thumbnail}))
        json_obj = json.loads(r.json())
        self.assertEqual(json_obj['id'], list_id)
        self.assertEqual(json_obj['title'], title)

    def test_app_playlist_delete(self):
        title = 'Testing app delete'
        thumbnail = 'some thumbnail delete'
        # Create the playlist first
        list_id = create_sample_playlist(title, thumbnail, TestApp.db_url)
        r = requests.delete(TestApp.playlists_api_url, params={'ssid': TestApp.session_id, 'lid': list_id})
        r.raise_for_status()

    def test_app_playlist_items_add_get(self):
        list_id = create_sample_playlist('items get', 'thumbnal.test', TestApp.db_url)
        test_items = [
            {'id' : '1abcd', 'title': 'some title1', 'thumbnail': 'itthumb1a', 'artist': 'artist a'},
            {'id' : '2abce', 'title': 'some title2', 'thumbnail': 'itthumb2b', 'artist': 'artist b'}]
        r = requests.post(TestApp.playlist_items_api_url, params={'ssid': TestApp.session_id, 'lid': list_id}, data=json.dumps({'items': test_items}))
        r.raise_for_status()
        r = requests.get(TestApp.playlist_items_api_url, params={'ssid': TestApp.session_id, 'lid': list_id})
        r.raise_for_status()
        self.assertTrue(r.headers.get('content-type', '').startswith('application/json'))
        json_obj = json.loads(r.json())
        self.assertEqual(json_obj['items'], test_items)

    def test_app_playlist_items_delete(self):
        list_id = create_sample_playlist('items delete', 'thumbnal.test', TestApp.db_url)
        test_items = [
            {'id' : '1abcd', 'title': 'some title1', 'thumbnail': 'itthumb1a', 'artist': 'artist a'},
            {'id' : '2abce', 'title': 'some title2', 'thumbnail': 'itthumb2b', 'artist': 'artist b'}]
        # Add the items
        r = requests.post(TestApp.playlist_items_api_url, params={'ssid': TestApp.session_id, 'lid': list_id}, data=json.dumps({'items': test_items}))
        r.raise_for_status()
        # Delete the item
        r = requests.delete(TestApp.playlist_items_api_url, params={'ssid': TestApp.session_id, 'lid': list_id, '_id': 'aaaaa'})
        self.assertEqual(r.status_code, 404)
        r = requests.delete(TestApp.playlist_items_api_url, params={'ssid': TestApp.session_id, 'lid': list_id, '_id': test_items[1]['id']})
        r.raise_for_status()
        db_items = get_playlist_items_from_db(list_id, TestApp.db_url)
        self.assertEqual(len(db_items), 1)
        self.assertEqual(db_items, test_items[0:1])

    def test_app_playlist_items_delete_slow(self):
        item_count = 1000
        list_id = create_sample_playlist('items delete slow', 'thumbnal.test', TestApp.db_url)
        item = {'id': 'QjXcf3wYfhc',
                'title': 'Jess Glynne No One (Jonas Blue Remix', 
                'thumbnail': 'https://lh3.googleusercontent.com/ET1uVviDNeKkr7LMkRcHLElE75EsW4dT6quWHlGKQgz36PkFmCQirCPQKu8rewziGgD6cZJvOtuc0yct=w544-h544-l90-rj',
                'artist': 'Jess Glynne'}
        test_items = [item for idx in range(0,item_count)]
        self.assertEqual(len(test_items), item_count)
        r = requests.post(TestApp.playlist_items_api_url, params={'ssid': TestApp.session_id, 'lid': list_id}, data=json.dumps({'items': test_items}))
        r.raise_for_status()
        # Check what we have in the databse
        db_items = get_playlist_items_from_db(list_id, TestApp.db_url)
        self.assertEqual(test_items, db_items)
        r = requests.delete(TestApp.playlist_items_api_url, params={'ssid': TestApp.session_id, 'lid': list_id, '_id': 'QjXcf3wYfhc'})
        r.raise_for_status()

    @classmethod
    def tearDownClass(cls):
        cls.app.shutdown()
        drop_db_tables(TestApp.db_url)



        
