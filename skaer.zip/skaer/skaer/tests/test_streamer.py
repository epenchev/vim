import os
import requests
import unittest


class StreamerTest(unittest.TestCase):
    """
    Test the streamer.

    """
    def setUp(self):
        super().setUp()
        self.url_endpoint = 'http://localhost:%s' % os.environ['PORT']

    def test_stream(self):
        req_params = { 'ytid': '3YxaaGgTQYM', 'ssid': '1' }
        response = requests.get(self.url_endpoint + '/stream', params=req_params)
        self.assertTrue(response.status_code == requests.codes.ok)
        self.assertTrue(response.headers['Content-Type'].startswith('audio'))
        response.close()
        # Test with invalid youtube id
        req_params = { 'ytid': 'xxxxx', 'ssid': '1' }
        response = requests.get(self.url_endpoint + '/stream', params=req_params)
        self.assertTrue(response.status_code != requests.codes.ok)
        response.close()

    def test_info(self):
        # Get info about a playlist
        req_params = { 'ytid': 'RDCLAK5uy_mfdqvCAl8wodlx2P2_Ai2gNkiRDAufkkI', 'ssid': '1', 'playlist': '1' }
        response = requests.get(self.url_endpoint + '/info', params=req_params)
        self.assertTrue(response.status_code == requests.codes.ok)
        self.assertTrue(response.headers['Content-Type'] == 'application/json')
        res = response.json()
        self.assertTrue(res['_type'] == 'playlist')
        self.assertTrue(len(res['entries']))
        response.close()
        # Test with invalid youtube id
        req_params = { 'ytid': '3YxaaGgTQ10', 'ssid': '1' }
        response = requests.get(self.url_endpoint + '/info', params=req_params)
        self.assertFalse(response.status_code == requests.codes.ok)
        response.close()

    def test_session_id(self):
        req_params = { 'ytid': '3YxaaGgTQYM', 'ssid': '1' }
        response = requests.head(self.url_endpoint + '/stream', params=req_params)
        self.assertTrue(response.status_code == requests.codes.ok)
        response.close()


if __name__ == '__main__':
    unittest.main()
