import os
import json
import requests
import cherrypy

from .playlists import Library
import skaer.metadata as metadata


class Skaer(object):
    """ Skaer app """

    def __init__(self):
        Library.init_db()

    @classmethod
    def user_allowed(cls, session_id : str) -> bool:
        """
        Validate user session with the server.
        :param session_id: string session id.

        """
        return True

    @cherrypy.expose()
    @cherrypy.tools.allow(methods=['GET'])
    def stream(self, track_id : str, session_id : str):
        """
        Stream audio.
        :param track_id: youtube video id.
        :param session_id: valid session id.

        """
        if not self.user_allowed(session_id):
            raise cherrypy.HTTPError(401, 'Unauthorized')

        range_header = None
        if 'Range' in cherrypy.request.headers:
               range_header = {'Range' : cherrypy.request.headers['Range']}
        try:
            stream_url, mime_type = Extractor.audio_stream(track_id)
        except Exception:
            raise cherrypy.HTTPError(404, 'Not found')
        # Fetch youtube audio source stream
        resp = requests.get(stream_url, headers=range_header, stream=True)
        if resp.status_code != requests.codes.ok:
             resp.raise_for_status()
        # stream to client
        cherrypy.response.headers.update({'Content-Type': mime_type})
        def content(resp):
            for chunk in resp.iter_content(chunk_size=10240):
                yield chunk
            resp.close()
        return content(resp)
    stream._cp_config = { 'response.stream': True }


    @cherrypy.expose()
    @cherrypy.tools.json_out()
    @cherrypy.tools.allow(methods=['GET'])
    def get_playlist(self, session_id : str, list_id : int=None):
        """
        Get a playlist with specifid id or return all playlists.
        :param session_id: valid session id.

        """
        if not self.user_allowed(session_id):
            raise cherrypy.HTTPError(401, 'Unauthorized')

        if list_id is not None:
            playlist = Library.playlist(int(list_id))
            return {'id': playlist.list_id, 'title': playlist.title, 'thumbnail': playlist.thumbnail, 'description': playlist.description}
            
        playlists = Library.all()
        json_objects = [{'id': p.list_id, 'title': p.title, 'thumbnail': p.thumbnail, 'description': p.description} for p in playlists]
        return {'playlists' : json_objects}

    @cherrypy.expose()
    @cherrypy.tools.json_out()
    @cherrypy.tools.allow(methods=['PUT'])
    def update_playlist(self, session_id : str, list_id : int) -> dict:
        """
        Update playlist data (title, thumbnail, description) not the tracks.
        :param session_id: valid session id.
        Return the updated playlist as json response.

        """
        if not self.user_allowed(session_id):
            raise cherrypy.HTTPError(401, 'Unauthorized')

        playlist = Library.playlist(int(list_id))
        if playlist is None:
            raise cherrypy.HTTPError(400, 'No playlist with this id')

        json_obj = json.loads(cherrypy.request.body.read())
        playlist.title = json_obj['title']
        playlist.thumbnail = json_obj['thumbnail']
        return {'id': playlist.list_id, 'title': playlist.title, 'thumbnail': playlist.thumbnail}

    @cherrypy.expose()
    @cherrypy.tools.json_out()
    @cherrypy.tools.allow(methods=['POST'])
    def create_playlist(self, session_id : str) -> dict:
        """
        Create a playlist with title, thumbnail and description.
        Return the created playlist as json response.

        """
        if not self.user_allowed(session_id):
            raise cherrypy.HTTPError(401, 'Unauthorized')

        json_obj = json.loads(cherrypy.request.body.read())
        playlist = Library.create(json_obj['title'], json_obj['thumbnail'], json_obj['description'])
        if playlist is None:
            raise cherrypy.HTTPError(409, 'Playlist exists')
        else:
            return {'id': playlist.list_id, 'title': playlist.title, 'thumbnail': playlist.thumbnail, 'description': playlist.description}

    @cherrypy.expose()
    @cherrypy.tools.allow(methods=['POST'])
    def delete_playlist(self, session_id : str, list_id : int):
        """
        Delete a playlist.
        :param session_id: valid session id.

        """
        if not self.user_allowed(session_id):
            raise cherrypy.HTTPError(401, 'Unauthorized')

        playlist = Library.playlist(int(list_id))
        if playlist is None:
            raise cherrypy.HTTPError(400, 'No playlist with this id')
        # Delete the tracks first
        playlist.clear()
        Library.delete(playlist.list_id)
        cherrypy.response.status = '204 No Content'

    #@cherrypy.expose()
    #@cherrypy.tools.json_out()
    #@cherrypy.tools.allow(methods=['GET', 'POST', 'PUT', 'DELETE'])
    #def playlists(self, session_id : str, list_id : int=None):
    #    """
    #    Expose the playlist api.
    #    Create, Read, Update and Delete a playlist.
    #    :param ssid: valid session id.
    #    :param lid: playlist id.
    #
    #    """
    #    if not self.user_allowed(session_id):
    #        raise cherrypy.HTTPError(401, 'Unauthorized')
    #
    #    # Get all playlists
    #    if cherrypy.request.method == 'GET' and lid is None:
    #        all_playlists = Library.all()
    #        json_objects = [{'id': p._lid, 'title': p.title, 'thumbnail': p.thumbnail} for p in all_playlists]
    #        return json.dumps({'playlists' : json_objects})
    #
    #    playlist = None
    #    if cherrypy.request.method in ('GET', 'PUT', 'DELETE'):
    #        if list_id is None:
    #            raise cherrypy.HTTPError(400, 'Missing valid playlist id')
    #        playlist = Library.playlist(int(list_id))
    #        if playlist is None:
    #            raise cherrypy.HTTPError(400, 'No playlist with this id')
    #
    #    if cherrypy.request.method == 'GET':
    #        # Get playlist
    #        return json.dumps({'id': playlist._lid, 'title': playlist.title, 'thumbnail': playlist.thumbnail})
    #    elif cherrypy.request.method == 'POST':
    #        # Create playlist
    #        json_obj = json.loads(cherrypy.request.body.read())
    #        playlist = Library.create(json_obj['title'], json_obj['thumbnail'])
    #        if playlist is None:
    #            raise cherrypy.HTTPError(409, 'Playlist exists')
    #        else:
    #            return json.dumps({'id': playlist._lid, 'title': playlist.title, 'thumbnail': playlist.thumbnail})
    #    elif cherrypy.request.method == 'PUT':
    #        # Edit playlist
    #        json_obj = json.loads(cherrypy.request.body.read())
    #        playlist.title = json_obj['title']
    #        playlist.thumbnail = json_obj['thumbnail']
    #        return json.dumps({'id': playlist._lid, 'title': playlist.title, 'thumbnail': playlist.thumbnail})
    #    elif cherrypy.request.method == 'DELETE':
    #        # Delete playlist and tracks as well
    #        playlist.clear()
    #        Library.delete(playlist._lid)
    #        cherrypy.response.status = '204 No Content'

    @cherrypy.expose()
    @cherrypy.tools.json_out()
    @cherrypy.tools.allow(methods=['GET', 'POST', 'DELETE'])
    def tracks(self, session_id : str, list_id : int, track_id : str=None):
        """
        Expose the playlist tracks api.
        List, Insert, and Delete playlist tracks.
        :param session_id: valid session id.
        :param list_id: playlist id.
        :param track_id: track id, only used when deleting a track from the list.

        """
        if not self.user_allowed(session_id):
            raise cherrypy.HTTPError(401, 'Unauthorized')
        if lid is None:
            raise cherrypy.HTTPError(400, 'Missing valid playlist id')

        playlist = Library.playlist(int(list_id))
        if playlist is None:
            raise cherrypy.HTTPError(400, 'No playlist with this id')

        # Get playlist tracks
        if cherrypy.request.method == 'GET':
            tracks_list = [track for track in playlist]
            return json.dumps({ 'tracks': tracks_list })
        # Add tracks to playlist
        elif cherrypy.request.method == 'POST':
            json_obj = json.loads(cherrypy.request.body.read())
            tracks = json_obj['tracks']
            playlist.extend(tracks)
            cherrypy.response.status = '204 No Content'
        # Delete a track from the playlist
        elif cherrypy.request.method == 'DELETE':
            try:
                playlist.remove_by_id(track_id)
                cherrypy.response.status = '204 No Content'
            except Exception:
                raise cherrypy.HTTPError(404, 'Not found')

    @cherrypy.expose()
    @cherrypy.tools.json_out()
    @cherrypy.tools.allow(methods=['POST'])
    def clone(self, session_id : str):
        """
        Clone a playlist from a url.
        :param session_id: valid session id.
        :param url: playlist url.

        """
        json_obj = json.loads(cherrypy.request.body.read())
        metadata.playlist_items(json_obj['url'])
        cherrypy.response.status = '204 No Content'

